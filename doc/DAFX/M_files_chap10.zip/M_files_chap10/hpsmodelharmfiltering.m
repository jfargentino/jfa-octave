%-----voice to clarinet-----%
%
%--------------------------------------------------------------------------
% This source code is provided without any warranties as published in 
% DAFX book 2nd edition, copyright Wiley & Sons 2011, available at 
% http://www.dafx.de. It may be used for educational purposes and not 
% for commercial applications without further permission.
%--------------------------------------------------------------------------

yhloc(2:2:end)=0; % set to zero the frequency of even harmonics 
                  % so that they won't be synthesized