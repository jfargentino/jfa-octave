%-----frequency scale-----%
fscale = 1.2;
ysloc = ysloc*fscale;